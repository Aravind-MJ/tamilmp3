<!-- Main Footer -->
      <footer class="main-footer">
        
        <!-- Default to the left -->
        <strong>Copyright &copy; 2016 <a href="http://imrokraft.com/">Imrokraft</a>.</strong> All rights reserved.
      </footer>    
  </body>
</html>